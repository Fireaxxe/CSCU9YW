
public class SimpleHelloService {
	
	public String echoMsg(String arg) {
		
		return arg.toUpperCase();
	}
}
