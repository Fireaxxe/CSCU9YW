package org.apache.ws.axis2;
import org.apache.ws.axis2.HelloWorldWSStub.EchoMsgResponse;

public class Client {
	
	public static void main(String[] args) throws Exception {
		
		HelloWorldWSStub stub = new HelloWorldWSStub();
		HelloWorldWSStub.EchoMsg request = new HelloWorldWSStub.EchoMsg();
		request.setArg("Hello world");
		
		EchoMsgResponse response = stub.echoMsg(request);
		System.out.println("Response : " + response.get_return());
	}

}
