/**
 * ApproverServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.4  Built on : Dec 28, 2015 (10:03:39 GMT)
 */
package approver;

/**
 *  ApproverServiceSkeleton java skeleton for the axisService
 */
public class ApproverServiceSkeleton {
    /**
     * Auto generated method signature
     *
     * @param approveOperation
     * @return approveOperationResponse
     */
    public approver.ApproveOperationResponse approveOperation(
        approver.ApproveOperation approveOperation) {
        //TODO : fill this with the necessary business logic
        throw new java.lang.UnsupportedOperationException("Please implement " +
            this.getClass().getName() + "#approveOperation");
    }
}
